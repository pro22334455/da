import { initializeApp, FirebaseApp } from "firebase/app";
import { getDatabase, ref, set, onValue, push, update, remove, onDisconnect, get, Database } from "firebase/database";
import { getAnalytics, Analytics } from "firebase/analytics";

/**
 * Firebase Configuration
 * Replace these placeholders with your actual Firebase project keys from the Firebase Console.
 */
const firebaseConfig = {
  apiKey: "REPLACE_WITH_YOUR_KEY",
  authDomain: "dama-ibra.firebaseapp.com",
  databaseURL: "https://dama-ibra-default-rtdb.firebaseio.com",
  projectId: "dama-ibra",
  storageBucket: "dama-ibra.appspot.com",
  messagingSenderId: "REPLACE_WITH_YOUR_SENDER_ID",
  appId: "REPLACE_WITH_YOUR_APP_ID",
  measurementId: "G-7Q81T7582J"
};

// Check if the config is still using placeholders
const isConfigValid = firebaseConfig.apiKey !== "REPLACE_WITH_YOUR_KEY" && 
                     !firebaseConfig.apiKey.startsWith("PLACEHOLDER");

let app: FirebaseApp | null = null;
let db: Database | any = null; // any used for safe fallback
let analytics: Analytics | null = null;

if (isConfigValid) {
  try {
    app = initializeApp(firebaseConfig);
    db = getDatabase(app);
    if (typeof window !== 'undefined') {
      analytics = getAnalytics(app);
    }
  } catch (error) {
    console.warn("Firebase failed to initialize:", error);
  }
} else {
  console.warn("Firebase is running in 'Mock Mode'. Please provide valid API keys in firebaseService.ts to enable multiplayer.");
  // Mock implementations to prevent app-wide crashes
  db = {
    // Basic mock of DB functionality for development
    ref: () => ({}),
    onValue: () => () => {},
    set: async () => {},
    push: () => ({ key: 'mock-key' }),
    update: async () => {},
    remove: async () => {},
    onDisconnect: () => ({}),
    get: async () => ({ exists: () => false, val: () => null })
  };
}

export { db, analytics, ref, set, onValue, push, update, remove, onDisconnect, get };

export const updateGlobalUserPoints = async (userId: string, pointsToAdd: number) => {
  if (!isConfigValid) return;
  const userRef = ref(db, `users/${userId}`);
  try {
    const snapshot = await get(userRef);
    if (snapshot.exists()) {
      const currentPoints = snapshot.val().points || 0;
      await update(userRef, { points: currentPoints + pointsToAdd });
    }
  } catch (error) {
    console.error("Error updating points:", error);
  }
};